/********************************************************************************
*  WEB322 – Assignment 02
* 
*  I declare that this assignment is my own work in accordance with Seneca's
*  Academic Integrity Policy:
* 
*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
* 
*  Name: _________Theodore Incoom Sakyi_____________ Student ID: ______151883220________ Date: _____10/23/24_________
*
********************************************************************************/

const projectData = require("./modules/projects");
const express = require('express');

const app = express();
const port = 3000;

projectData.Initialize()
    .then(() => {
        app.listen(port, () => {
            console.log(`Server is running on http://localhost:${port}`);
        });
    })
    .catch(err => {
        console.error("Failed to initialize projects:", err);
    });

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/views/home.html');
});

app.get('/about', (req, res) => {
    res.sendFile(__dirname + '/views/about.html');
});

app.get('/solutions/projects', (req, res) => {
    const sector = req.query.sector;

    if (sector) {
        projectData.getProjectsBySector(sector)
            .then(projects => res.json(projects))
            .catch(err => res.status(404).send(err));
    } else {
        projectData.getAllProjects()
            .then(projects => res.json(projects))
            .catch(err => res.status(404).send(err));
    }
});

app.get('/solutions/projects/:id', (req, res) => {
    const projectId = parseInt(req.params.id);
    projectData.getProjectById(projectId)
        .then(project => res.json(project))
        .catch(err => res.status(404).send(err));
});

app.use((req, res) => {
    res.status(404).sendFile(__dirname + '/views/404.html');
});

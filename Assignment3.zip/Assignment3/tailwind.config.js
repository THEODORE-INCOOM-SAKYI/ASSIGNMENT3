module.exports = {
  content: [
    './**/*.html',
    './**/*.js'
  ],
  theme: {
    extend: {},
  },
  plugins: [require('daisyui')],
};

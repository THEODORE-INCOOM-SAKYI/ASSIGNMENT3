const projectData = require("../data/projectData");
const sectorData = require("../data/sectorData");

let projects = [];

function Initialize() {
    return new Promise((resolve, reject) => {
        try {
            projects = [];
            projectData.forEach(project => {
                const sector = sectorData.find(s => s.id === project.sector_id);
                const projectWithSector = {
                    ...project,
                    sector: sector ? sector.sector_name : "Unknown"
                };
                projects.push(projectWithSector);
            });
            resolve();  
        } catch (error) {
            reject("Error initializing projects: " + error.message);
        }
    });
}

function getAllProjects() {
    return new Promise((resolve, reject) => {
        if (projects.length > 0) {
            resolve(projects);
        } else {
            reject("No projects found");
        }
    });
}

function getProjectById(projectId) {
    return new Promise((resolve, reject) => {
        const project = projects.find(project => project.id === projectId);
        if (project) {
            resolve(project);
        } else {
            reject(`Unable to find project with ID ${projectId}`);
        }
    });
}

function getProjectsBySector(sector) {
    return new Promise((resolve, reject) => {
        const filteredProjects = projects.filter(project => 
            project.sector.toLowerCase().includes(sector.toLowerCase())
        );
        if (filteredProjects.length > 0) {
            resolve(filteredProjects);
        } else {
            reject(`No projects found for sector: ${sector}`);
        }
    });
}


Initialize()
    .then(() => getAllProjects())
    .then(allProjects => console.log("All Projects:", allProjects))
    .then(() => getProjectById(9))
    .then(project => console.log("Project by ID:", project))
    .then(() => getProjectsBySector("agriculture"))
    .then(projectsBySector => console.log("Projects by Sector:", projectsBySector))
    .catch(error => console.error(error));


module.exports = {
    Initialize,
    getAllProjects,
    getProjectById,
    getProjectsBySector
};
